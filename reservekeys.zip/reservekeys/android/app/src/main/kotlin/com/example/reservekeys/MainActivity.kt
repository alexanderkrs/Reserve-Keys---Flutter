package com.example.reservekeys

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
