import 'package:flutter/material.dart';
import 'models/chave.dart';
import 'service/api_service.dart';

enum Gender { male, female }

enum Status { positive, dead, recovered }

class EditDataWidget extends StatefulWidget {
  EditDataWidget(this.chave);

  final Chave chave;

  @override
  _EditDataWidgetState createState() => _EditDataWidgetState();
}

class _EditDataWidgetState extends State<EditDataWidget> {
  _EditDataWidgetState();

  final ApiService api = ApiService();
  String id = '';
  final _addFormKey = GlobalKey<FormState>();
  final numController = TextEditingController();
  final localController = TextEditingController();
  final statusController = TextEditingController();
  final descController = TextEditingController();

  @override
  void initState() {
    id = widget.chave.id;
    numController.text = widget.chave.num.toString();
    localController.text = widget.chave.local;
    statusController.text = widget.chave.status;
    descController.text = widget.chave.desc;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Editar Chave'),
      ),
      body: Form(
        key: _addFormKey,
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(20.0),
            child: Card(
                child: Container(
                    padding: EdgeInsets.all(10.0),
                    width: 440,
                    child: Column(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Column(
                            children: <Widget>[
                              Text('Local da chave:'),
                              TextFormField(
                                controller: localController,
                                decoration: const InputDecoration(
                                  hintText: 'Local da chave:',
                                ),
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Por favor, preencher o local da chave...';
                                  }
                                  return null;
                                },
                                onChanged: (value) {},
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Column(
                            children: <Widget>[
                              Text('Número da chave:'),
                              TextFormField(
                                controller: numController,
                                decoration: const InputDecoration(
                                  hintText: 'Número da chave...',
                                ),
                                keyboardType: TextInputType.number,
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Por favor, preencher o número da chave.';
                                  }
                                  return null;
                                },
                                onChanged: (value) {},
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Column(
                            children: <Widget>[
                              Text('Descrição da chave:'),
                              TextFormField(
                                controller: descController,
                                decoration: const InputDecoration(
                                  hintText: 'Descrição da chave...',
                                ),
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Por favor, preencher a descrição da chave.';
                                  }
                                  return null;
                                },
                                onChanged: (value) {},
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Column(
                            children: <Widget>[
                              ElevatedButton(
                                onPressed: () {
                                  if (_addFormKey.currentState!.validate()) {
                                    _addFormKey.currentState!.save();
                                    api.updateChave(
                                        id,
                                        Chave(
                                            local: localController.text,
                                            num: int.parse(numController.text),
                                            status: statusController.text,
                                            desc: descController.text,
                                            id: ''));

                                    Navigator.pop(context);
                                  }
                                },
                                child: Text('Salvar',
                                    style: TextStyle(color: Colors.white)),
                              )
                            ],
                          ),
                        ),
                      ],
                    ))),
          ),
        ),
      ),
    );
  }
}
