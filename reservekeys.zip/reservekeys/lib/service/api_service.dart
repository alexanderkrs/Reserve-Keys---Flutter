import 'dart:convert';
import 'dart:ffi';

import 'package:http/http.dart';

import '../models/chave.dart';

class ApiService {
  final String apiUrl = "http://192.168.15.11:8080/chaves";

  Future<List<Chave>> getChave() async {
    Response res = await get(apiUrl);

    if (res.statusCode == 200) {
      List<dynamic> body = jsonDecode(res.body);
      List<Chave> chave =
          body.map((dynamic item) => Chave.fromJson(item)).toList();
      return chave;
    } else if (res.statusCode == 404) {
      return <Chave>[];
    } else {
      throw "Failed to load cases list";
    }
  }

  Future<Chave> getChaveById(String id) async {
    final response = await get('$apiUrl/$id');

    if (response.statusCode == 200) {
      print("GetChaveByID:" + id);
      return Chave.fromJson(json.decode(response.body));
    } else {
      throw Exception('Failed to load a chave');
    }
  }

  Future<Chave> createChave(Chave chave) async {
    Map data = {
      'num': chave.num,
      'local': chave.local,
      'desc': chave.desc,
      'chave': chave.status
    };

    final Response response = await post(
      apiUrl,
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(data),
    );
    if (response.statusCode == 200) {
      return Chave.fromJson(json.decode(response.body));
    } else {
      print(data);
      throw Exception('Failed to post chave');
    }
  }

  Future<Chave> updateChave(String id, Chave chave) async {
    Map data = {
      'num': chave.num,
      'local': chave.local,
      'desc': chave.desc,
      'status': chave.status
    };

    final Response response = await put(
      '$apiUrl/$id',
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(data),
    );
    if (response.statusCode == 200) {
      return Chave.fromJson(json.decode(response.body));
    } else {
      throw Exception('Atualização da chave falhou');
    }
  }

  Future<void> deleteChave(String id) async {
    Response res = await delete('$apiUrl/$id');

    if (res.statusCode == 200) {
      print("Chave excluída");
    } else {
      throw "Exclusão da chave falhou.";
    }
  }
}
