import 'dart:ffi';

import 'package:flutter/material.dart';
import 'detailwidget.dart';
import 'models/chave.dart';

class ChaveList extends StatelessWidget {
  final List<Chave> chave;
  const ChaveList({super.key, required this.chave});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
        itemCount: chave == null ? 0 : chave.length,
        itemBuilder: (BuildContext context, int index) {
          return Card(
              child: InkWell(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => DetailWidget(chave[index])),
              );
            },
            child: ListTile(
                leading: Icon(Icons.key),
                title: Text(
                    chave[index].local + ' - ' + chave[index].num.toString()),
                subtitle:
                    Text(chave[index].desc + ' - ' + chave[index].status)),
          ));
        });
  }
}
