class Chave {
  final String id;
  final int num;
  final String local;
  final String desc;
  final String status;

  Chave(
      {required this.id,
      required this.num,
      required this.local,
      required this.desc,
      required this.status});

  factory Chave.fromJson(Map<String, dynamic> json) {
    return Chave(
      id: (json['id'] as int).toString(),
      num: json['num'] as int,
      local: json['local'] as String,
      desc: json['desc'] as String,
      status: json['status'] as String,
    );
  }

  @override
  String toString() {
    return 'Trans{id: $id, num: $num, local: $local, desc: $desc, status: $status}';
  }
}
