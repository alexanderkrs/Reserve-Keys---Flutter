import 'package:flutter/material.dart';
import 'models/chave.dart';
import 'service/api_service.dart';

class AddDataWidget extends StatefulWidget {
  AddDataWidget();

  @override
  _AddDataWidgetState createState() => _AddDataWidgetState();
}

class _AddDataWidgetState extends State<AddDataWidget> {
  _AddDataWidgetState();

  final ApiService api = ApiService();
  final _addFormKey = GlobalKey<FormState>();
  final numController = TextEditingController();
  final localController = TextEditingController();
  final statusController = TextEditingController();
  final descController = TextEditingController();
  String local = 'positive';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Chave'),
      ),
      body: Form(
        key: _addFormKey,
        child: SingleChildScrollView(
          child: Container(
            padding: EdgeInsets.all(20.0),
            child: Card(
                child: Container(
                    padding: EdgeInsets.all(10.0),
                    width: 440,
                    child: Column(
                      children: <Widget>[
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Column(
                            children: <Widget>[
                              Text('Local da Chave'),
                              TextFormField(
                                controller: localController,
                                decoration: const InputDecoration(
                                  hintText: 'Local da Chave...',
                                ),
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Preenche o local da chave';
                                  }
                                  return null;
                                },
                                onChanged: (value) {},
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Column(
                            children: <Widget>[
                              Text('Numero da Chave'),
                              TextFormField(
                                controller: numController,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  hintText: 'Número da Chave...',
                                ),
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Preencher o número da chave';
                                  }
                                  return null;
                                },
                                onChanged: (value) {},
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Column(
                            children: <Widget>[
                              Text('Descrição da Chave'),
                              TextFormField(
                                controller: descController,
                                decoration: const InputDecoration(
                                  hintText: 'Descrição da Chave...',
                                ),
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return 'Preencher a descrição da chave';
                                  }
                                  return null;
                                },
                                onChanged: (value) {},
                              ),
                            ],
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0, 10),
                          child: Column(
                            children: <Widget>[
                              ElevatedButton(
                                onPressed: () {
                                  if (_addFormKey.currentState!.validate()) {
                                    _addFormKey.currentState!.save();
                                    api.createChave(Chave(
                                      id: '',
                                      num: int.parse(numController.text),
                                      local: localController.text,
                                      status: statusController.text,
                                      desc: descController.text,
                                    ));

                                    Navigator.pop(context);
                                  }
                                },
                                child: Text('Salvar',
                                    style: TextStyle(color: Colors.white)),
                              )
                            ],
                          ),
                        ),
                      ],
                    ))),
          ),
        ),
      ),
    );
  }
}
